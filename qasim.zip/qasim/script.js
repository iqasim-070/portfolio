// Current year
document.getElementById("year").textContent = new Date().getFullYear();

// Dark/Light Mode
const themeToggle = document.getElementById("theme-toggle");
themeToggle.addEventListener("click", () => {
  document.documentElement.classList.toggle("dark");
  themeToggle.textContent = document.documentElement.classList.contains("dark") ? "☀️" : "🌙";
});

// Contact form (UI only)
function handleContact() {
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();
  const feedback = document.getElementById("contact-feedback");

  if (!name || !email || !message) {
    feedback.textContent = "Please fill in all fields!";
    feedback.style.color = "red";
  } else {
    feedback.textContent = `Thanks, ${name}! Message previewed (UI only).`;
    feedback.style.color = "green";
  }
}
